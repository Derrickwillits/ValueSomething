export class UserTemplate {
  id: number;
  name: string;
}