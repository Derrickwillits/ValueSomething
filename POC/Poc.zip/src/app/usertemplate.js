"use strict";
var UserTemplate = (function () {
    function UserTemplate() {
    }
    return UserTemplate;
}());
exports.UserTemplate = UserTemplate;
//# sourceMappingURL=usertemplate.js.map